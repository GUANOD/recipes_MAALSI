function createAuthControllers(User) {
  const loginForm = (req, res) => {
    res.render("loginForm");
  };
  const login = () => {};
  const create = () => {};

  return { login, create, loginForm };
}

export { createAuthControllers };
