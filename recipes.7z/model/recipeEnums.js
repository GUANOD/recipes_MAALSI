import mongoose from 'mongoose'
const difficultyEnum = ['Easy','Medium','Hard']
const priceEnum = [1,2,3,4,5]

export { difficultyEnum,priceEnum}